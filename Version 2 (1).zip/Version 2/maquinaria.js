let maquinaria = JSON.parse(localStorage.getItem('maquinaria') || '[]');
let editingId = null;

// Función para convertir archivo a base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Función para previsualizar foto
function previewFoto(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const previewImg = document.getElementById(previewId + 'Img');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.style.display = 'none';
    }
}

// Cargar maquinaria
function loadMaquinaria() {
    const tbody = document.getElementById('maquinariaBody');
    const emptyState = document.getElementById('emptyMaquinaria');
    
    if (maquinaria.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }

    emptyState.style.display = 'none';
    tbody.innerHTML = maquinaria.map(item => {
        const estadoBadge = getEstadoBadge(item.estado);
        const fotoHtml = item.fotografia 
            ? `<img src="${item.fotografia}" alt="Foto" class="img-thumbnail" style="max-width: 60px; max-height: 60px; cursor: pointer;" onclick="mostrarFotoGrande('${item.fotografia}')">`
            : '<span class="text-muted">Sin foto</span>';
        
        return `
            <tr>
                <td>${item.codigo}</td>
                <td>${item.nombre}</td>
                <td>${item.tipo}</td>
                <td>${item.marca || ''} ${item.modelo || ''}</td>
                <td><span class="badge ${estadoBadge}">${item.estado.replace('_', ' ')}</span></td>
                <td>${item.horas_uso_total || 0} hrs</td>
                <td>${item.horas_uso_semana || 0} hrs</td>
                <td>${item.responsable || '-'}</td>
                <td>${fotoHtml}</td>
                <td>
                    <button class="btn btn-sm btn-outline-success me-1" onclick="openUsoModal('${item.id}')" title="Registrar Uso">
                        <i class="bi bi-clock-history"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editMaquinaria('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteMaquinaria('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');

    updateTipoFilter();
}

// Obtener badge según estado
function getEstadoBadge(estado) {
    const badges = {
        disponible: 'bg-success',
        en_uso: 'bg-warning',
        mantenimiento: 'bg-info',
        fuera_servicio: 'bg-danger'
    };
    return badges[estado] || 'bg-secondary';
}

// Guardar maquinaria
async function saveMaquinaria(event) {
    event.preventDefault();
    
    if (!Utils.validateForm('formMaquinaria')) return;

    // Obtener foto si existe
    let fotoBase64 = null;
    const fotoInput = document.getElementById('fotografia');
    if (fotoInput.files && fotoInput.files[0]) {
        try {
            fotoBase64 = await fileToBase64(fotoInput.files[0]);
        } catch (error) {
            Utils.showAlert('Error al procesar la imagen', 'danger');
            return;
        }
    } else if (editingId) {
        // Si estamos editando y no hay nueva foto, mantener la existente
        const itemExistente = maquinaria.find(m => m.id === editingId);
        if (itemExistente && itemExistente.fotografia) {
            fotoBase64 = itemExistente.fotografia;
        }
    }

    const item = {
        id: editingId || Utils.generateId(),
        codigo: document.getElementById('codigo').value,
        nombre: document.getElementById('nombre').value,
        tipo: document.getElementById('tipo').value,
        marca: document.getElementById('marca').value,
        modelo: document.getElementById('modelo').value,
        numero_serie: document.getElementById('numero_serie').value,
        estado: document.getElementById('estado').value,
        responsable: document.getElementById('responsable').value,
        ubicacion_actual: document.getElementById('ubicacion_actual').value,
        fotografia: fotoBase64,
        horas_uso_total: maquinaria.find(m => m.id === editingId)?.horas_uso_total || 0,
        horas_uso_semana: maquinaria.find(m => m.id === editingId)?.horas_uso_semana || 0,
        fecha_recepcion: maquinaria.find(m => m.id === editingId)?.fecha_recepcion || new Date().toISOString(),
        fecha_ultima_actualizacion: new Date().toISOString()
    };

    if (editingId) {
        const index = maquinaria.findIndex(m => m.id === editingId);
        maquinaria[index] = item;
        Utils.showAlert('Maquinaria actualizada correctamente', 'success');
    } else {
        maquinaria.push(item);
        Utils.showAlert('Maquinaria agregada correctamente', 'success');
    }

    localStorage.setItem('maquinaria', JSON.stringify(maquinaria));
    loadMaquinaria();
    bootstrap.Modal.getInstance(document.getElementById('modalMaquinaria')).hide();
    resetForm();
}

// Editar maquinaria
function editMaquinaria(id) {
    const item = maquinaria.find(m => m.id === id);
    if (!item) return;

    editingId = id;
    document.getElementById('modalMaquinariaTitle').textContent = 'Editar Maquinaria';
    document.getElementById('maquinariaId').value = id;
    document.getElementById('codigo').value = item.codigo;
    document.getElementById('nombre').value = item.nombre;
    document.getElementById('tipo').value = item.tipo;
    document.getElementById('marca').value = item.marca || '';
    document.getElementById('modelo').value = item.modelo || '';
    document.getElementById('numero_serie').value = item.numero_serie || '';
    document.getElementById('estado').value = item.estado;
    document.getElementById('responsable').value = item.responsable || '';
    document.getElementById('ubicacion_actual').value = item.ubicacion_actual || '';
    
    // Cargar foto si existe
    const fotoPreview = document.getElementById('fotoPreview');
    const fotoPreviewImg = document.getElementById('fotoPreviewImg');
    if (item.fotografia) {
        fotoPreviewImg.src = item.fotografia;
        fotoPreview.style.display = 'block';
    } else {
        fotoPreview.style.display = 'none';
    }
    
    // Limpiar input de archivo
    document.getElementById('fotografia').value = '';

    new bootstrap.Modal(document.getElementById('modalMaquinaria')).show();
}

// Eliminar maquinaria
function deleteMaquinaria(id) {
    if (!confirm('¿Estás seguro de eliminar esta maquinaria?')) return;

    maquinaria = maquinaria.filter(m => m.id !== id);
    localStorage.setItem('maquinaria', JSON.stringify(maquinaria));
    loadMaquinaria();
    Utils.showAlert('Maquinaria eliminada correctamente', 'success');
}

// Abrir modal de uso
function openUsoModal(id) {
    document.getElementById('usoMaquinariaId').value = id;
    document.getElementById('fecha_entrega').value = new Date().toISOString().split('T')[0];
    document.getElementById('horas_uso').value = '';
    new bootstrap.Modal(document.getElementById('modalUso')).show();
}

// Registrar uso
function registrarUso(event) {
    event.preventDefault();
    
    if (!Utils.validateForm('formUso')) return;

    const id = document.getElementById('usoMaquinariaId').value;
    const horas = parseFloat(document.getElementById('horas_uso').value);
    const fechaEntrega = document.getElementById('fecha_entrega').value;

    const item = maquinaria.find(m => m.id === id);
    if (item) {
        item.horas_uso_total = (item.horas_uso_total || 0) + horas;
        item.horas_uso_semana = (item.horas_uso_semana || 0) + horas;
        item.fecha_ultima_entrega = fechaEntrega;
        item.fecha_ultima_actualizacion = new Date().toISOString();
        item.estado = 'disponible';

        localStorage.setItem('maquinaria', JSON.stringify(maquinaria));
        loadMaquinaria();
        bootstrap.Modal.getInstance(document.getElementById('modalUso')).hide();
        Utils.showAlert('Uso registrado correctamente', 'success');
    }
}

// Filtrar maquinaria
function filterMaquinaria() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const tipo = document.getElementById('tipoFilter').value;
    const estado = document.getElementById('estadoFilter').value;

    const tbody = document.getElementById('maquinariaBody');
    const filtered = maquinaria.filter(item => {
        const matchesSearch = !search || 
            item.nombre.toLowerCase().includes(search) ||
            item.codigo.toLowerCase().includes(search);
        const matchesTipo = !tipo || item.tipo === tipo;
        const matchesEstado = !estado || item.estado === estado;

        return matchesSearch && matchesTipo && matchesEstado;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No se encontraron resultados</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(item => {
        const estadoBadge = getEstadoBadge(item.estado);
        const fotoHtml = item.fotografia 
            ? `<img src="${item.fotografia}" alt="Foto" class="img-thumbnail" style="max-width: 60px; max-height: 60px; cursor: pointer;" onclick="mostrarFotoGrande('${item.fotografia}')">`
            : '<span class="text-muted">Sin foto</span>';
        
        return `
            <tr>
                <td>${item.codigo}</td>
                <td>${item.nombre}</td>
                <td>${item.tipo}</td>
                <td>${item.marca || ''} ${item.modelo || ''}</td>
                <td><span class="badge ${estadoBadge}">${item.estado.replace('_', ' ')}</span></td>
                <td>${item.horas_uso_total || 0} hrs</td>
                <td>${item.horas_uso_semana || 0} hrs</td>
                <td>${item.responsable || '-'}</td>
                <td>${fotoHtml}</td>
                <td>
                    <button class="btn btn-sm btn-outline-success me-1" onclick="openUsoModal('${item.id}')" title="Registrar Uso">
                        <i class="bi bi-clock-history"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editMaquinaria('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteMaquinaria('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Actualizar filtro de tipos
function updateTipoFilter() {
    const tipos = [...new Set(maquinaria.map(m => m.tipo))];
    const select = document.getElementById('tipoFilter');
    const currentValue = select.value;
    
    select.innerHTML = '<option value="">Todos los tipos</option>' +
        tipos.map(tipo => `<option value="${tipo}">${tipo}</option>`).join('');
    
    select.value = currentValue;
}

// Resetear formulario
function resetForm() {
    editingId = null;
    document.getElementById('modalMaquinariaTitle').textContent = 'Nueva Maquinaria';
    document.getElementById('formMaquinaria').reset();
    document.getElementById('formMaquinaria').classList.remove('was-validated');
    document.getElementById('fotoPreview').style.display = 'none';
    document.getElementById('fotoPreviewImg').src = '';
}

// Mostrar foto en tamaño grande
function mostrarFotoGrande(fotoSrc) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Fotografía</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <img src="${fotoSrc}" alt="Fotografía" class="img-fluid">
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
    });
}

// Cuando se cierra el modal, resetear el formulario
document.getElementById('modalMaquinaria').addEventListener('hidden.bs.modal', resetForm);

// Cargar al iniciar
loadMaquinaria();


