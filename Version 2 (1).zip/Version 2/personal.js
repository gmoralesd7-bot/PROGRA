let personal = JSON.parse(localStorage.getItem('personal') || '[]');
let asistencias = JSON.parse(localStorage.getItem('asistencias') || '[]');
let editingId = null;

// Cargar fecha de hoy
document.getElementById('fechaHoy').textContent = new Date().toLocaleDateString('es-ES', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
});

// Cargar personal
function loadPersonal() {
    const tbody = document.getElementById('personalBody');
    const emptyState = document.getElementById('emptyPersonal');
    
    if (personal.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        loadAsistenciaHoy();
        loadHistorial();
        updatePersonalSelect();
        return;
    }

    emptyState.style.display = 'none';
    tbody.innerHTML = personal.filter(p => p.activo !== false).map(item => {
        const asistenciaHoy = getAsistenciaHoy(item.id);
        const estadoBadge = asistenciaHoy ? getEstadoBadge(asistenciaHoy.estado) : 'bg-secondary';
        const estadoText = asistenciaHoy ? asistenciaHoy.estado : 'Sin registro';
        
        return `
            <tr>
                <td>${item.codigo_empleado}</td>
                <td>${item.nombre} ${item.apellido}</td>
                <td>${item.cargo}</td>
                <td>${item.departamento || '-'}</td>
                <td>${item.telefono || '-'}</td>
                <td><span class="badge ${estadoBadge}">${estadoText}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-success me-1" onclick="openAsistenciaModal('${item.id}')" title="Registrar Asistencia">
                        <i class="bi bi-clock-history"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editPersonal('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deletePersonal('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');

    loadAsistenciaHoy();
    loadHistorial();
    updatePersonalSelect();
}

// Cargar asistencia de hoy
function loadAsistenciaHoy() {
    const hoy = new Date().toISOString().split('T')[0];
    const asistenciaHoy = asistencias.filter(a => a.fecha === hoy);
    const tbody = document.getElementById('asistenciaHoyBody');
    const emptyState = document.getElementById('emptyAsistenciaHoy');

    if (asistenciaHoy.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }

    emptyState.style.display = 'none';
    tbody.innerHTML = asistenciaHoy.map(asistencia => {
        const empleado = personal.find(p => p.id === asistencia.personal_id);
        if (!empleado) return '';

        const horas = calcularHoras(asistencia.hora_entrada, asistencia.hora_salida);
        const estadoBadge = getEstadoBadge(asistencia.estado);

        return `
            <tr>
                <td>${empleado.nombre} ${empleado.apellido}</td>
                <td>${empleado.cargo}</td>
                <td>${asistencia.hora_entrada || '-'}</td>
                <td>${asistencia.hora_salida || '-'}</td>
                <td>${horas} hrs</td>
                <td><span class="badge ${estadoBadge}">${asistencia.estado}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editAsistencia('${asistencia.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Cargar historial
function loadHistorial() {
    const personalId = document.getElementById('personalFilter').value;
    const fechaDesde = document.getElementById('fechaDesde').value;
    const fechaHasta = document.getElementById('fechaHasta').value;

    let filtered = asistencias;

    if (personalId) {
        filtered = filtered.filter(a => a.personal_id === personalId);
    }
    if (fechaDesde) {
        filtered = filtered.filter(a => a.fecha >= fechaDesde);
    }
    if (fechaHasta) {
        filtered = filtered.filter(a => a.fecha <= fechaHasta);
    }

    filtered.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));

    const tbody = document.getElementById('historialBody');
    const emptyState = document.getElementById('emptyHistorial');

    if (filtered.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }

    emptyState.style.display = 'none';
    tbody.innerHTML = filtered.slice(0, 50).map(asistencia => {
        const empleado = personal.find(p => p.id === asistencia.personal_id);
        if (!empleado) return '';

        const horas = calcularHoras(asistencia.hora_entrada, asistencia.hora_salida);
        const estadoBadge = getEstadoBadge(asistencia.estado);

        return `
            <tr>
                <td>${Utils.formatDate(asistencia.fecha)}</td>
                <td>${empleado.nombre} ${empleado.apellido}</td>
                <td>${empleado.cargo}</td>
                <td>${asistencia.hora_entrada || '-'}</td>
                <td>${asistencia.hora_salida || '-'}</td>
                <td>${horas} hrs</td>
                <td><span class="badge ${estadoBadge}">${asistencia.estado}</span></td>
            </tr>
        `;
    }).join('');
}

// Obtener asistencia de hoy para un empleado
function getAsistenciaHoy(personalId) {
    const hoy = new Date().toISOString().split('T')[0];
    return asistencias.find(a => a.personal_id === personalId && a.fecha === hoy);
}

// Calcular horas trabajadas
function calcularHoras(entrada, salida) {
    if (!entrada || !salida) return '0.0';
    const [h1, m1] = entrada.split(':').map(Number);
    const [h2, m2] = salida.split(':').map(Number);
    const horas = (h2 - h1) + (m2 - m1) / 60;
    return horas.toFixed(1);
}

// Obtener badge según estado
function getEstadoBadge(estado) {
    const badges = {
        presente: 'bg-success',
        tardanza: 'bg-warning',
        falta: 'bg-danger',
        permiso: 'bg-info'
    };
    return badges[estado] || 'bg-secondary';
}

// Guardar personal
function savePersonal(event) {
    event.preventDefault();
    
    if (!Utils.validateForm('formPersonal')) return;

    const item = {
        id: editingId || Utils.generateId(),
        codigo_empleado: document.getElementById('codigo_empleado').value,
        nombre: document.getElementById('nombre').value,
        apellido: document.getElementById('apellido').value,
        cargo: document.getElementById('cargo').value,
        departamento: document.getElementById('departamento').value,
        telefono: document.getElementById('telefono').value,
        email: document.getElementById('email').value,
        activo: true
    };

    if (editingId) {
        const index = personal.findIndex(p => p.id === editingId);
        personal[index] = item;
        Utils.showAlert('Personal actualizado correctamente', 'success');
    } else {
        personal.push(item);
        Utils.showAlert('Personal agregado correctamente', 'success');
    }

    localStorage.setItem('personal', JSON.stringify(personal));
    loadPersonal();
    bootstrap.Modal.getInstance(document.getElementById('modalPersonal')).hide();
    resetForm();
}

// Editar personal
function editPersonal(id) {
    const item = personal.find(p => p.id === id);
    if (!item) return;

    editingId = id;
    document.getElementById('modalPersonalTitle').textContent = 'Editar Personal';
    document.getElementById('personalId').value = id;
    document.getElementById('codigo_empleado').value = item.codigo_empleado;
    document.getElementById('nombre').value = item.nombre;
    document.getElementById('apellido').value = item.apellido;
    document.getElementById('cargo').value = item.cargo;
    document.getElementById('departamento').value = item.departamento || '';
    document.getElementById('telefono').value = item.telefono || '';
    document.getElementById('email').value = item.email || '';

    new bootstrap.Modal(document.getElementById('modalPersonal')).show();
}

// Eliminar personal
function deletePersonal(id) {
    if (!confirm('¿Estás seguro de eliminar este personal?')) return;

    const item = personal.find(p => p.id === id);
    if (item) {
        item.activo = false;
        localStorage.setItem('personal', JSON.stringify(personal));
        loadPersonal();
        Utils.showAlert('Personal eliminado correctamente', 'success');
    }
}

// Abrir modal de asistencia
function openAsistenciaModal(personalId = null) {
    document.getElementById('asistenciaPersonalId').value = personalId || '';
    document.getElementById('asistenciaId').value = '';
    document.getElementById('fechaAsistencia').value = new Date().toISOString().split('T')[0];
    document.getElementById('hora_entrada').value = '';
    document.getElementById('hora_salida').value = '';
    document.getElementById('estadoAsistencia').value = 'presente';
    document.getElementById('observaciones').value = '';

    if (personalId) {
        document.getElementById('personalSelect').value = personalId;
        document.getElementById('personalSelect').disabled = true;
    } else {
        document.getElementById('personalSelect').disabled = false;
    }

    updatePersonalSelect();
    new bootstrap.Modal(document.getElementById('modalAsistencia')).show();
}

// Editar asistencia
function editAsistencia(id) {
    const asistencia = asistencias.find(a => a.id === id);
    if (!asistencia) return;

    document.getElementById('asistenciaId').value = id;
    document.getElementById('asistenciaPersonalId').value = asistencia.personal_id;
    document.getElementById('personalSelect').value = asistencia.personal_id;
    document.getElementById('personalSelect').disabled = true;
    document.getElementById('fechaAsistencia').value = asistencia.fecha;
    document.getElementById('hora_entrada').value = asistencia.hora_entrada || '';
    document.getElementById('hora_salida').value = asistencia.hora_salida || '';
    document.getElementById('estadoAsistencia').value = asistencia.estado;
    document.getElementById('observaciones').value = asistencia.observaciones || '';

    updatePersonalSelect();
    new bootstrap.Modal(document.getElementById('modalAsistencia')).show();
}

// Guardar asistencia
function saveAsistencia(event) {
    event.preventDefault();
    
    if (!Utils.validateForm('formAsistencia')) return;

    const personalId = document.getElementById('personalSelect').value;
    const fecha = document.getElementById('fechaAsistencia').value;
    const horaEntrada = document.getElementById('hora_entrada').value;
    const horaSalida = document.getElementById('hora_salida').value;
    const estado = document.getElementById('estadoAsistencia').value;
    const observaciones = document.getElementById('observaciones').value;
    const asistenciaId = document.getElementById('asistenciaId').value;

    // Verificar si ya existe un registro para este día
    const existingIndex = asistencias.findIndex(a => 
        a.personal_id === personalId && a.fecha === fecha && a.id !== asistenciaId
    );

    const horasTrabajadas = horaEntrada && horaSalida ? 
        calcularHoras(horaEntrada, horaSalida) : 0;

    const asistencia = {
        id: asistenciaId || Utils.generateId(),
        personal_id: personalId,
        fecha: fecha,
        hora_entrada: horaEntrada,
        hora_salida: horaSalida,
        horas_trabajadas: parseFloat(horasTrabajadas),
        estado: estado,
        observaciones: observaciones
    };

    if (asistenciaId) {
        const index = asistencias.findIndex(a => a.id === asistenciaId);
        asistencias[index] = asistencia;
        Utils.showAlert('Asistencia actualizada correctamente', 'success');
    } else if (existingIndex >= 0) {
        asistencias[existingIndex] = asistencia;
        Utils.showAlert('Asistencia actualizada correctamente', 'success');
    } else {
        asistencias.push(asistencia);
        Utils.showAlert('Asistencia registrada correctamente', 'success');
    }

    localStorage.setItem('asistencias', JSON.stringify(asistencias));
    loadPersonal();
    bootstrap.Modal.getInstance(document.getElementById('modalAsistencia')).hide();
    resetForm();
}

// Actualizar select de personal
function updatePersonalSelect() {
    const select = document.getElementById('personalSelect');
    const currentValue = select.value;
    
    select.innerHTML = '<option value="">Seleccionar empleado</option>' +
        personal.filter(p => p.activo !== false).map(p => 
            `<option value="${p.id}">${p.nombre} ${p.apellido} - ${p.cargo}</option>`
        ).join('');
    
    select.value = currentValue;

    // Actualizar filtro de historial
    const filterSelect = document.getElementById('personalFilter');
    filterSelect.innerHTML = '<option value="">Todos los empleados</option>' +
        personal.filter(p => p.activo !== false).map(p => 
            `<option value="${p.id}">${p.nombre} ${p.apellido}</option>`
        ).join('');
}

// Filtrar personal
function filterPersonal() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const filtered = personal.filter(p => 
        p.activo !== false && (
            p.nombre.toLowerCase().includes(search) ||
            p.apellido.toLowerCase().includes(search) ||
            p.codigo_empleado.toLowerCase().includes(search) ||
            p.cargo.toLowerCase().includes(search)
        )
    );

    const tbody = document.getElementById('personalBody');
    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No se encontraron resultados</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(item => {
        const asistenciaHoy = getAsistenciaHoy(item.id);
        const estadoBadge = asistenciaHoy ? getEstadoBadge(asistenciaHoy.estado) : 'bg-secondary';
        const estadoText = asistenciaHoy ? asistenciaHoy.estado : 'Sin registro';
        
        return `
            <tr>
                <td>${item.codigo_empleado}</td>
                <td>${item.nombre} ${item.apellido}</td>
                <td>${item.cargo}</td>
                <td>${item.departamento || '-'}</td>
                <td>${item.telefono || '-'}</td>
                <td><span class="badge ${estadoBadge}">${estadoText}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-success me-1" onclick="openAsistenciaModal('${item.id}')" title="Registrar Asistencia">
                        <i class="bi bi-clock-history"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="editPersonal('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deletePersonal('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Filtrar historial
function filterHistorial() {
    loadHistorial();
}

// Resetear formulario
function resetForm() {
    editingId = null;
    document.getElementById('modalPersonalTitle').textContent = 'Nuevo Personal';
    document.getElementById('formPersonal').reset();
    document.getElementById('formPersonal').classList.remove('was-validated');
    document.getElementById('formAsistencia').reset();
    document.getElementById('formAsistencia').classList.remove('was-validated');
    document.getElementById('personalSelect').disabled = false;
}

// Cuando se cierra el modal, resetear el formulario
document.getElementById('modalPersonal').addEventListener('hidden.bs.modal', resetForm);
document.getElementById('modalAsistencia').addEventListener('hidden.bs.modal', function() {
    document.getElementById('formAsistencia').reset();
    document.getElementById('formAsistencia').classList.remove('was-validated');
    document.getElementById('personalSelect').disabled = false;
});

// Cargar al iniciar
loadPersonal();


