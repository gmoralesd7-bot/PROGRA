let actividades = JSON.parse(localStorage.getItem('actividades') || '[]');
let editingId = null;

// Función para convertir archivo a base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Función para obtener el tipo de archivo
function getFileType(fileName) {
    const ext = fileName.split('.').pop().toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) return 'imagen';
    if (['pdf'].includes(ext)) return 'pdf';
    if (['dwg', 'dxf'].includes(ext)) return 'plano';
    if (['xlsx', 'xls'].includes(ext)) return 'excel';
    if (['doc', 'docx'].includes(ext)) return 'word';
    return 'archivo';
}

// Función para obtener el icono según el tipo de archivo
function getFileIcon(fileType) {
    const icons = {
        imagen: 'bi-image',
        pdf: 'bi-file-pdf',
        plano: 'bi-file-earmark-ruled',
        excel: 'bi-file-earmark-spreadsheet',
        word: 'bi-file-earmark-word',
        archivo: 'bi-file-earmark'
    };
    return icons[fileType] || icons.archivo;
}

// Función para previsualizar archivos
function previewArchivos(inputId, previewId, tipo) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    
    if (!input.files || input.files.length === 0) {
        preview.innerHTML = '';
        return;
    }
    
    let html = '<div class="d-flex flex-wrap gap-2">';
    Array.from(input.files).forEach((file, index) => {
        const fileType = getFileType(file.name);
        const icon = getFileIcon(fileType);
        html += `
            <div class="badge bg-secondary d-flex align-items-center gap-1">
                <i class="bi ${icon}"></i>
                <span style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${file.name}</span>
            </div>
        `;
    });
    html += '</div>';
    preview.innerHTML = html;
}

// Cargar actividades
function loadActividades() {
    const tbody = document.getElementById('actividadesBody');
    const emptyState = document.getElementById('emptyActividades');
    
    // Verificar actividades atrasadas
    actividades.forEach(act => {
        if (act.estado !== 'completada' && act.estado !== 'cancelada') {
            const fechaFin = new Date(act.fecha_fin_planificada);
            const hoy = new Date();
            if (fechaFin < hoy) {
                act.estado = 'atrasada';
            }
        }
    });
    localStorage.setItem('actividades', JSON.stringify(actividades));

    if (actividades.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        updateStats();
        return;
    }

    emptyState.style.display = 'none';
    tbody.innerHTML = actividades.map(item => {
        const estadoBadge = getEstadoBadge(item.estado);
        const prioridadBadge = getPrioridadBadge(item.prioridad);
        
        // Contar documentos
        const totalDocs = (item.planos?.length || 0) + 
                         (item.presupuestos?.length || 0) + 
                         (item.contratos?.length || 0) + 
                         (item.fotografias?.length || 0);
        
        const docsHtml = totalDocs > 0 
            ? `<button class="btn btn-sm btn-outline-info" onclick="verDocumentos('${item.id}')" title="Ver documentos">
                   <i class="bi bi-folder"></i> ${totalDocs}
               </button>`
            : '<span class="text-muted">Sin documentos</span>';
        
        return `
            <tr>
                <td>${item.codigo}</td>
                <td>${item.titulo}</td>
                <td>${item.tipo}</td>
                <td><span class="badge ${prioridadBadge}">${item.prioridad}</span></td>
                <td><span class="badge ${estadoBadge}">${item.estado.replace('_', ' ')}</span></td>
                <td>
                    <div class="progress" style="height: 25px;">
                        <div class="progress-bar ${getProgressBarClass(item.porcentaje_avance)}" 
                             style="width: ${item.porcentaje_avance}%" 
                             role="progressbar">
                            ${item.porcentaje_avance}%
                        </div>
                    </div>
                </td>
                <td>${Utils.formatDate(item.fecha_inicio_planificada)}</td>
                <td>${Utils.formatDate(item.fecha_fin_planificada)}</td>
                <td>${item.responsable || '-'}</td>
                <td>${docsHtml}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editActividad('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteActividad('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');

    updateStats();
}

// Actualizar estadísticas
function updateStats() {
    const total = actividades.length;
    const completadas = actividades.filter(a => a.estado === 'completada').length;
    const enProgreso = actividades.filter(a => a.estado === 'en_progreso').length;
    const atrasadas = actividades.filter(a => a.estado === 'atrasada').length;

    document.getElementById('totalActividades').textContent = total;
    document.getElementById('completadas').textContent = completadas;
    document.getElementById('enProgreso').textContent = enProgreso;
    document.getElementById('atrasadas').textContent = atrasadas;
}

// Obtener badge según estado
function getEstadoBadge(estado) {
    const badges = {
        pendiente: 'bg-secondary',
        en_progreso: 'bg-primary',
        completada: 'bg-success',
        atrasada: 'bg-danger',
        cancelada: 'bg-dark'
    };
    return badges[estado] || 'bg-secondary';
}

// Obtener badge según prioridad
function getPrioridadBadge(prioridad) {
    const badges = {
        baja: 'bg-info',
        media: 'bg-warning',
        alta: 'bg-danger',
        urgente: 'bg-dark'
    };
    return badges[prioridad] || 'bg-secondary';
}

// Obtener clase de barra de progreso
function getProgressBarClass(porcentaje) {
    if (porcentaje === 100) return 'bg-success';
    if (porcentaje >= 50) return 'bg-primary';
    if (porcentaje >= 25) return 'bg-warning';
    return 'bg-secondary';
}

// Guardar actividad
async function saveActividad(event) {
    event.preventDefault();
    
    if (!Utils.validateForm('formActividad')) return;

    const porcentaje = parseInt(document.getElementById('porcentaje_avance').value) || 0;
    let estado = document.getElementById('estado').value;
    
    // Si el porcentaje es 100%, marcar como completada
    if (porcentaje === 100) {
        estado = 'completada';
    }

    // Procesar archivos
    let planos = [];
    let presupuestos = [];
    let contratos = [];
    let fotografias = [];

    // Si estamos editando, mantener archivos existentes
    if (editingId) {
        const actividadExistente = actividades.find(a => a.id === editingId);
        if (actividadExistente) {
            planos = actividadExistente.planos || [];
            presupuestos = actividadExistente.presupuestos || [];
            contratos = actividadExistente.contratos || [];
            fotografias = actividadExistente.fotografias || [];
        }
    }

    // Procesar nuevos planos
    const planosInput = document.getElementById('planos');
    if (planosInput.files && planosInput.files.length > 0) {
        try {
            const nuevosPlanos = await Promise.all(
                Array.from(planosInput.files).map(async (file) => ({
                    nombre: file.name,
                    tipo: getFileType(file.name),
                    contenido: await fileToBase64(file),
                    fecha: new Date().toISOString()
                }))
            );
            planos = [...planos, ...nuevosPlanos];
        } catch (error) {
            Utils.showAlert('Error al procesar planos', 'danger');
            return;
        }
    }

    // Procesar nuevos presupuestos
    const presupuestosInput = document.getElementById('presupuestos');
    if (presupuestosInput.files && presupuestosInput.files.length > 0) {
        try {
            const nuevosPresupuestos = await Promise.all(
                Array.from(presupuestosInput.files).map(async (file) => ({
                    nombre: file.name,
                    tipo: getFileType(file.name),
                    contenido: await fileToBase64(file),
                    fecha: new Date().toISOString()
                }))
            );
            presupuestos = [...presupuestos, ...nuevosPresupuestos];
        } catch (error) {
            Utils.showAlert('Error al procesar presupuestos', 'danger');
            return;
        }
    }

    // Procesar nuevos contratos
    const contratosInput = document.getElementById('contratos');
    if (contratosInput.files && contratosInput.files.length > 0) {
        try {
            const nuevosContratos = await Promise.all(
                Array.from(contratosInput.files).map(async (file) => ({
                    nombre: file.name,
                    tipo: getFileType(file.name),
                    contenido: await fileToBase64(file),
                    fecha: new Date().toISOString()
                }))
            );
            contratos = [...contratos, ...nuevosContratos];
        } catch (error) {
            Utils.showAlert('Error al procesar contratos', 'danger');
            return;
        }
    }

    // Procesar nuevas fotografías
    const fotografiasInput = document.getElementById('fotografias');
    if (fotografiasInput.files && fotografiasInput.files.length > 0) {
        try {
            const nuevasFotografias = await Promise.all(
                Array.from(fotografiasInput.files).map(async (file) => ({
                    nombre: file.name,
                    tipo: 'imagen',
                    contenido: await fileToBase64(file),
                    fecha: new Date().toISOString()
                }))
            );
            fotografias = [...fotografias, ...nuevasFotografias];
        } catch (error) {
            Utils.showAlert('Error al procesar fotografías', 'danger');
            return;
        }
    }

    const actividad = {
        id: editingId || Utils.generateId(),
        codigo: document.getElementById('codigo').value,
        titulo: document.getElementById('titulo').value,
        tipo: document.getElementById('tipo').value,
        prioridad: document.getElementById('prioridad').value,
        estado: estado,
        fecha_inicio_planificada: document.getElementById('fecha_inicio').value,
        fecha_fin_planificada: document.getElementById('fecha_fin').value,
        responsable: document.getElementById('responsable').value,
        porcentaje_avance: porcentaje,
        descripcion: document.getElementById('descripcion').value,
        planos: planos,
        presupuestos: presupuestos,
        contratos: contratos,
        fotografias: fotografias,
        fecha_creacion: actividades.find(a => a.id === editingId)?.fecha_creacion || new Date().toISOString()
    };

    if (editingId) {
        const index = actividades.findIndex(a => a.id === editingId);
        actividades[index] = actividad;
        Utils.showAlert('Actividad actualizada correctamente', 'success');
    } else {
        actividades.push(actividad);
        Utils.showAlert('Actividad agregada correctamente', 'success');
    }

    localStorage.setItem('actividades', JSON.stringify(actividades));
    loadActividades();
    bootstrap.Modal.getInstance(document.getElementById('modalActividad')).hide();
    resetForm();
}

// Editar actividad
function editActividad(id) {
    const actividad = actividades.find(a => a.id === id);
    if (!actividad) return;

    editingId = id;
    document.getElementById('modalActividadTitle').textContent = 'Editar Actividad';
    document.getElementById('actividadId').value = id;
    document.getElementById('codigo').value = actividad.codigo;
    document.getElementById('titulo').value = actividad.titulo;
    document.getElementById('tipo').value = actividad.tipo;
    document.getElementById('prioridad').value = actividad.prioridad;
    document.getElementById('estado').value = actividad.estado;
    document.getElementById('fecha_inicio').value = actividad.fecha_inicio_planificada;
    document.getElementById('fecha_fin').value = actividad.fecha_fin_planificada;
    document.getElementById('responsable').value = actividad.responsable || '';
    document.getElementById('porcentaje_avance').value = actividad.porcentaje_avance || 0;
    document.getElementById('descripcion').value = actividad.descripcion || '';

    // Mostrar archivos existentes
    mostrarArchivosExistentes('planosPreview', actividad.planos || []);
    mostrarArchivosExistentes('presupuestosPreview', actividad.presupuestos || []);
    mostrarArchivosExistentes('contratosPreview', actividad.contratos || []);
    mostrarArchivosExistentes('fotografiasPreview', actividad.fotografias || []);

    // Limpiar inputs de archivo
    document.getElementById('planos').value = '';
    document.getElementById('presupuestos').value = '';
    document.getElementById('contratos').value = '';
    document.getElementById('fotografias').value = '';

    new bootstrap.Modal(document.getElementById('modalActividad')).show();
}

// Mostrar archivos existentes
function mostrarArchivosExistentes(previewId, archivos) {
    const preview = document.getElementById(previewId);
    if (!archivos || archivos.length === 0) {
        preview.innerHTML = '';
        return;
    }
    
    let html = '<div class="d-flex flex-wrap gap-2 mb-2"><small class="text-muted">Archivos existentes:</small></div><div class="d-flex flex-wrap gap-2">';
    archivos.forEach((archivo) => {
        const icon = getFileIcon(archivo.tipo);
        html += `
            <div class="badge bg-info d-flex align-items-center gap-1">
                <i class="bi ${icon}"></i>
                <span style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${archivo.nombre}</span>
            </div>
        `;
    });
    html += '</div>';
    preview.innerHTML = html;
}

// Eliminar actividad
function deleteActividad(id) {
    if (!confirm('¿Estás seguro de eliminar esta actividad?')) return;

    actividades = actividades.filter(a => a.id !== id);
    localStorage.setItem('actividades', JSON.stringify(actividades));
    loadActividades();
    Utils.showAlert('Actividad eliminada correctamente', 'success');
}

// Filtrar actividades
function filterActividades() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const estado = document.getElementById('estadoFilter').value;
    const tipo = document.getElementById('tipoFilter').value;
    const prioridad = document.getElementById('prioridadFilter').value;

    const tbody = document.getElementById('actividadesBody');
    const filtered = actividades.filter(item => {
        const matchesSearch = !search || 
            item.titulo.toLowerCase().includes(search) ||
            item.codigo.toLowerCase().includes(search);
        const matchesEstado = !estado || item.estado === estado;
        const matchesTipo = !tipo || item.tipo === tipo;
        const matchesPrioridad = !prioridad || item.prioridad === prioridad;

        return matchesSearch && matchesEstado && matchesTipo && matchesPrioridad;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" class="text-center text-muted">No se encontraron resultados</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(item => {
        const estadoBadge = getEstadoBadge(item.estado);
        const prioridadBadge = getPrioridadBadge(item.prioridad);
        
        // Contar documentos
        const totalDocs = (item.planos?.length || 0) + 
                         (item.presupuestos?.length || 0) + 
                         (item.contratos?.length || 0) + 
                         (item.fotografias?.length || 0);
        
        const docsHtml = totalDocs > 0 
            ? `<button class="btn btn-sm btn-outline-info" onclick="verDocumentos('${item.id}')" title="Ver documentos">
                   <i class="bi bi-folder"></i> ${totalDocs}
               </button>`
            : '<span class="text-muted">Sin documentos</span>';
        
        return `
            <tr>
                <td>${item.codigo}</td>
                <td>${item.titulo}</td>
                <td>${item.tipo}</td>
                <td><span class="badge ${prioridadBadge}">${item.prioridad}</span></td>
                <td><span class="badge ${estadoBadge}">${item.estado.replace('_', ' ')}</span></td>
                <td>
                    <div class="progress" style="height: 25px;">
                        <div class="progress-bar ${getProgressBarClass(item.porcentaje_avance)}" 
                             style="width: ${item.porcentaje_avance}%" 
                             role="progressbar">
                            ${item.porcentaje_avance}%
                        </div>
                    </div>
                </td>
                <td>${Utils.formatDate(item.fecha_inicio_planificada)}</td>
                <td>${Utils.formatDate(item.fecha_fin_planificada)}</td>
                <td>${item.responsable || '-'}</td>
                <td>${docsHtml}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editActividad('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteActividad('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Resetear formulario
function resetForm() {
    editingId = null;
    document.getElementById('modalActividadTitle').textContent = 'Nueva Actividad';
    document.getElementById('formActividad').reset();
    document.getElementById('formActividad').classList.remove('was-validated');
    document.getElementById('porcentaje_avance').value = 0;
    
    // Limpiar previews de archivos
    document.getElementById('planosPreview').innerHTML = '';
    document.getElementById('presupuestosPreview').innerHTML = '';
    document.getElementById('contratosPreview').innerHTML = '';
    document.getElementById('fotografiasPreview').innerHTML = '';
}

// Ver documentos de una actividad
function verDocumentos(id) {
    const actividad = actividades.find(a => a.id === id);
    if (!actividad) return;

    const totalDocs = (actividad.planos?.length || 0) + 
                     (actividad.presupuestos?.length || 0) + 
                     (actividad.contratos?.length || 0) + 
                     (actividad.fotografias?.length || 0);

    if (totalDocs === 0) {
        Utils.showAlert('No hay documentos asociados a esta actividad', 'info');
        return;
    }

    let contenido = `
        <div class="row g-3">
    `;

    // Planos
    if (actividad.planos && actividad.planos.length > 0) {
        contenido += `
            <div class="col-12">
                <h6><i class="bi bi-file-earmark-ruled"></i> Planos (${actividad.planos.length})</h6>
                <div class="list-group">
        `;
        actividad.planos.forEach((plano, index) => {
            const icon = getFileIcon(plano.tipo);
            contenido += `
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <i class="bi ${icon}"></i> ${plano.nombre}
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-primary" onclick="descargarArchivo('${id}', 'planos', ${index})">
                            <i class="bi bi-download"></i> Descargar
                        </button>
                        ${plano.tipo === 'imagen' ? `
                            <button class="btn btn-sm btn-outline-info" onclick="verImagenDesdeActividad('${id}', 'planos', ${index})">
                                <i class="bi bi-eye"></i> Ver
                            </button>
                        ` : ''}
                    </div>
                </div>
            `;
        });
        contenido += `</div></div>`;
    }

    // Presupuestos
    if (actividad.presupuestos && actividad.presupuestos.length > 0) {
        contenido += `
            <div class="col-12">
                <h6><i class="bi bi-file-earmark-spreadsheet"></i> Presupuestos (${actividad.presupuestos.length})</h6>
                <div class="list-group">
        `;
        actividad.presupuestos.forEach((presupuesto, index) => {
            const icon = getFileIcon(presupuesto.tipo);
            contenido += `
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <i class="bi ${icon}"></i> ${presupuesto.nombre}
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-primary" onclick="descargarArchivo('${id}', 'presupuestos', ${index})">
                            <i class="bi bi-download"></i> Descargar
                        </button>
                    </div>
                </div>
            `;
        });
        contenido += `</div></div>`;
    }

    // Contratos
    if (actividad.contratos && actividad.contratos.length > 0) {
        contenido += `
            <div class="col-12">
                <h6><i class="bi bi-file-earmark-text"></i> Contratos (${actividad.contratos.length})</h6>
                <div class="list-group">
        `;
        actividad.contratos.forEach((contrato, index) => {
            const icon = getFileIcon(contrato.tipo);
            contenido += `
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <i class="bi ${icon}"></i> ${contrato.nombre}
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-primary" onclick="descargarArchivo('${id}', 'contratos', ${index})">
                            <i class="bi bi-download"></i> Descargar
                        </button>
                    </div>
                </div>
            `;
        });
        contenido += `</div></div>`;
    }

    // Fotografías
    if (actividad.fotografias && actividad.fotografias.length > 0) {
        contenido += `
            <div class="col-12">
                <h6><i class="bi bi-images"></i> Fotografías del Avance (${actividad.fotografias.length})</h6>
                <div class="row g-2">
        `;
        actividad.fotografias.forEach((foto, index) => {
            // Escapar comillas simples y dobles en el contenido base64 para evitar problemas en el HTML
            const contenidoEscapado = foto.contenido.replace(/'/g, "\\'").replace(/"/g, '&quot;');
            contenido += `
                <div class="col-md-3">
                    <div class="card">
                        <img src="${contenidoEscapado}" class="card-img-top" alt="${foto.nombre}" style="height: 150px; object-fit: cover; cursor: pointer;" onclick="verImagenDesdeActividad('${id}', 'fotografias', ${index})">
                        <div class="card-body p-2">
                            <small class="text-muted d-block" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${foto.nombre}</small>
                            <button class="btn btn-sm btn-outline-primary mt-1" onclick="descargarArchivo('${id}', 'fotografias', ${index})">
                                <i class="bi bi-download"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        contenido += `</div></div>`;
    }

    contenido += `</div>`;

    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Documentos - ${actividad.titulo}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ${contenido}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
    });
}

// Descargar archivo
function descargarArchivo(actividadId, tipo, index) {
    const actividad = actividades.find(a => a.id === actividadId);
    if (!actividad) return;

    const archivos = actividad[tipo];
    if (!archivos || !archivos[index]) return;

    const archivo = archivos[index];
    const link = document.createElement('a');
    link.href = archivo.contenido;
    link.download = archivo.nombre;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Ver imagen desde actividad (más seguro que pasar base64 directamente)
function verImagenDesdeActividad(actividadId, tipo, index) {
    const actividad = actividades.find(a => a.id === actividadId);
    if (!actividad) return;

    const archivos = actividad[tipo];
    if (!archivos || !archivos[index]) return;

    const archivo = archivos[index];
    if (archivo.tipo !== 'imagen') return;

    verImagen(archivo.contenido);
}

// Ver imagen en tamaño grande
function verImagen(imagenSrc) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Imagen</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <img src="${imagenSrc}" alt="Imagen" class="img-fluid">
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
    });
}

// Cuando se cierra el modal, resetear el formulario
document.getElementById('modalActividad').addEventListener('hidden.bs.modal', resetForm);

// Cargar al iniciar
loadActividades();


