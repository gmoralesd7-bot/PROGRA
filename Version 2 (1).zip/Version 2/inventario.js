let inventario = JSON.parse(localStorage.getItem('inventario') || '[]');
let editingId = null;

// Función para convertir archivo a base64
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

// Función para previsualizar foto
function previewFoto(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const previewImg = document.getElementById(previewId + 'Img');
    
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.style.display = 'none';
    }
}

// Cargar inventario
function loadInventario() {
    const tbody = document.getElementById('inventarioBody');
    const emptyState = document.getElementById('emptyInventario');
    
    if (inventario.length === 0) {
        tbody.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }

    emptyState.style.display = 'none';
    tbody.innerHTML = inventario.map(item => {
        const estado = getEstado(item.cantidad_actual, item.cantidad_minima);
        const estadoBadge = getEstadoBadge(estado);
        const fotoHtml = item.fotografia 
            ? `<img src="${item.fotografia}" alt="Foto" class="img-thumbnail" style="max-width: 60px; max-height: 60px; cursor: pointer;" onclick="mostrarFotoGrande('${item.fotografia}')">`
            : '<span class="text-muted">Sin foto</span>';
        
        return `
            <tr>
                <td>${item.codigo}</td>
                <td>${item.nombre}</td>
                <td>${item.categoria}</td>
                <td>${item.cantidad_actual}</td>
                <td>${item.cantidad_minima}</td>
                <td>${item.unidad_medida}</td>
                <td><span class="badge ${estadoBadge}">${estado.replace('_', ' ')}</span></td>
                <td>${item.ubicacion || '-'}</td>
                <td>${fotoHtml}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editInventario('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteInventario('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');

    // Actualizar categorías en el filtro
    updateCategoriaFilter();
}

// Obtener estado según cantidad
function getEstado(cantidad, minimo) {
    if (cantidad <= 0) return 'agotado';
    if (cantidad <= minimo) return 'bajo_stock';
    return 'disponible';
}

// Obtener badge según estado
function getEstadoBadge(estado) {
    const badges = {
        disponible: 'bg-success',
        bajo_stock: 'bg-warning',
        agotado: 'bg-danger'
    };
    return badges[estado] || 'bg-secondary';
}

// Guardar item
async function saveInventario(event) {
    event.preventDefault();
    
    if (!Utils.validateForm('formInventario')) return;

    // Obtener foto si existe
    let fotoBase64 = null;
    const fotoInput = document.getElementById('fotografia');
    if (fotoInput.files && fotoInput.files[0]) {
        try {
            fotoBase64 = await fileToBase64(fotoInput.files[0]);
        } catch (error) {
            Utils.showAlert('Error al procesar la imagen', 'danger');
            return;
        }
    } else if (editingId) {
        // Si estamos editando y no hay nueva foto, mantener la existente
        const itemExistente = inventario.find(i => i.id === editingId);
        if (itemExistente && itemExistente.fotografia) {
            fotoBase64 = itemExistente.fotografia;
        }
    }

    const item = {
        id: editingId || Utils.generateId(),
        codigo: document.getElementById('codigo').value,
        nombre: document.getElementById('nombre').value,
        categoria: document.getElementById('categoria').value,
        unidad_medida: document.getElementById('unidad_medida').value,
        cantidad_actual: parseFloat(document.getElementById('cantidad_actual').value),
        cantidad_minima: parseFloat(document.getElementById('cantidad_minima').value),
        precio_unitario: parseFloat(document.getElementById('precio_unitario').value) || 0,
        ubicacion: document.getElementById('ubicacion').value,
        descripcion: document.getElementById('descripcion').value,
        fotografia: fotoBase64,
        fecha_actualizacion: new Date().toISOString()
    };

    if (editingId) {
        const index = inventario.findIndex(i => i.id === editingId);
        inventario[index] = item;
        Utils.showAlert('Item actualizado correctamente', 'success');
    } else {
        inventario.push(item);
        Utils.showAlert('Item agregado correctamente', 'success');
    }

    localStorage.setItem('inventario', JSON.stringify(inventario));
    loadInventario();
    bootstrap.Modal.getInstance(document.getElementById('modalInventario')).hide();
    resetForm();
}

// Editar item
function editInventario(id) {
    const item = inventario.find(i => i.id === id);
    if (!item) return;

    editingId = id;
    document.getElementById('modalInventarioTitle').textContent = 'Editar Item';
    document.getElementById('inventarioId').value = id;
    document.getElementById('codigo').value = item.codigo;
    document.getElementById('nombre').value = item.nombre;
    document.getElementById('categoria').value = item.categoria;
    document.getElementById('unidad_medida').value = item.unidad_medida;
    document.getElementById('cantidad_actual').value = item.cantidad_actual;
    document.getElementById('cantidad_minima').value = item.cantidad_minima;
    document.getElementById('precio_unitario').value = item.precio_unitario || '';
    document.getElementById('ubicacion').value = item.ubicacion || '';
    document.getElementById('descripcion').value = item.descripcion || '';
    
    // Cargar foto si existe
    const fotoPreview = document.getElementById('fotoPreview');
    const fotoPreviewImg = document.getElementById('fotoPreviewImg');
    if (item.fotografia) {
        fotoPreviewImg.src = item.fotografia;
        fotoPreview.style.display = 'block';
    } else {
        fotoPreview.style.display = 'none';
    }
    
    // Limpiar input de archivo
    document.getElementById('fotografia').value = '';

    new bootstrap.Modal(document.getElementById('modalInventario')).show();
}

// Eliminar item
function deleteInventario(id) {
    if (!confirm('¿Estás seguro de eliminar este item?')) return;

    inventario = inventario.filter(i => i.id !== id);
    localStorage.setItem('inventario', JSON.stringify(inventario));
    loadInventario();
    Utils.showAlert('Item eliminado correctamente', 'success');
}

// Filtrar inventario
function filterInventario() {
    const search = document.getElementById('searchInput').value.toLowerCase();
    const categoria = document.getElementById('categoriaFilter').value;
    const estado = document.getElementById('estadoFilter').value;

    const tbody = document.getElementById('inventarioBody');
    const filtered = inventario.filter(item => {
        const matchesSearch = !search || 
            item.nombre.toLowerCase().includes(search) ||
            item.codigo.toLowerCase().includes(search);
        const matchesCategoria = !categoria || item.categoria === categoria;
        const itemEstado = getEstado(item.cantidad_actual, item.cantidad_minima);
        const matchesEstado = !estado || itemEstado === estado;

        return matchesSearch && matchesCategoria && matchesEstado;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">No se encontraron resultados</td></tr>';
        return;
    }

    tbody.innerHTML = filtered.map(item => {
        const estado = getEstado(item.cantidad_actual, item.cantidad_minima);
        const estadoBadge = getEstadoBadge(estado);
        const fotoHtml = item.fotografia 
            ? `<img src="${item.fotografia}" alt="Foto" class="img-thumbnail" style="max-width: 60px; max-height: 60px; cursor: pointer;" onclick="mostrarFotoGrande('${item.fotografia}')">`
            : '<span class="text-muted">Sin foto</span>';
        
        return `
            <tr>
                <td>${item.codigo}</td>
                <td>${item.nombre}</td>
                <td>${item.categoria}</td>
                <td>${item.cantidad_actual}</td>
                <td>${item.cantidad_minima}</td>
                <td>${item.unidad_medida}</td>
                <td><span class="badge ${estadoBadge}">${estado.replace('_', ' ')}</span></td>
                <td>${item.ubicacion || '-'}</td>
                <td>${fotoHtml}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editInventario('${item.id}')">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteInventario('${item.id}')">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Actualizar filtro de categorías
function updateCategoriaFilter() {
    const categorias = [...new Set(inventario.map(i => i.categoria))];
    const select = document.getElementById('categoriaFilter');
    const currentValue = select.value;
    
    select.innerHTML = '<option value="">Todas las categorías</option>' +
        categorias.map(cat => `<option value="${cat}">${cat}</option>`).join('');
    
    select.value = currentValue;
}

// Resetear formulario
function resetForm() {
    editingId = null;
    document.getElementById('modalInventarioTitle').textContent = 'Nuevo Item';
    document.getElementById('formInventario').reset();
    document.getElementById('formInventario').classList.remove('was-validated');
    document.getElementById('fotoPreview').style.display = 'none';
    document.getElementById('fotoPreviewImg').src = '';
}

// Mostrar foto en tamaño grande
function mostrarFotoGrande(fotoSrc) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Fotografía</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center">
                    <img src="${fotoSrc}" alt="Fotografía" class="img-fluid">
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
    });
}

// Cuando se cierra el modal, resetear el formulario
document.getElementById('modalInventario').addEventListener('hidden.bs.modal', resetForm);

// Cargar al iniciar
loadInventario();


