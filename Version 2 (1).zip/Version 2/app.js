// Navegación entre páginas
function navigateTo(page) {
    window.location.href = page;
}

// Cargar estadísticas del dashboard
function loadDashboardStats() {
    // Inventario
    const inventario = JSON.parse(localStorage.getItem('inventario') || '[]');
    document.getElementById('totalInventario').textContent = inventario.length;

    // Maquinaria
    const maquinaria = JSON.parse(localStorage.getItem('maquinaria') || '[]');
    document.getElementById('totalMaquinaria').textContent = maquinaria.length;

    // Actividades
    const actividades = JSON.parse(localStorage.getItem('actividades') || '[]');
    document.getElementById('totalActividades').textContent = actividades.length;

    // Personal
    const personal = JSON.parse(localStorage.getItem('personal') || '[]');
    document.getElementById('totalPersonal').textContent = personal.length;
}

// Utilidades generales
const Utils = {
    // Formatear fecha
    formatDate(date) {
        if (!date) return '';
        const d = new Date(date);
        return d.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        });
    },

    // Formatear hora
    formatTime(time) {
        if (!time) return '';
        return time.substring(0, 5);
    },

    // Generar ID único
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    // Mostrar alerta
    showAlert(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.insertBefore(alertDiv, document.body.firstChild);
        setTimeout(() => alertDiv.remove(), 5000);
    },

    // Validar formulario
    validateForm(formId) {
        const form = document.getElementById(formId);
        if (!form.checkValidity()) {
            form.classList.add('was-validated');
            return false;
        }
        return true;
    }
};

// Inicializar cuando la página cargue
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('totalInventario')) {
        loadDashboardStats();
    }
});


